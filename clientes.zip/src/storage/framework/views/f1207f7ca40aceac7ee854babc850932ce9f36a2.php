;

<?php $__env->startSection('body'); ?>
    <div class="card border">
        <div class="card-body">
            <form <?php if(isset($produto)): ?> action="/produtos/salvar/<?php echo e($produto->id); ?>" <?php else: ?> action="/produtos" <?php endif; ?> method="post">
              <?php echo csrf_field(); ?>

              <?php if(isset($produto)): ?>
                <?php echo method_field('PUT'); ?>
              <?php endif; ?>

              <div class="form-group">
                <label for="nomeproduto">Nome</label>
                <input class="form-control" type="text" id="nomeproduto" name="nome" <?php if(isset($produto)): ?> value="<?php echo e($produto->nome); ?>" <?php endif; ?>>
              </div>

              <div class="form-group">
                <label for="estoque">Estoque</label>
                <input class="form-control" type="number" id="estoque" name="estoque" <?php if(isset($produto)): ?> value="<?php echo e($produto->stock); ?>" <?php endif; ?>>
              </div>

              <div class="form-group">
                <label for="preco">Preço</label>
                <input class="form-control" type="number" id="preco" name="preco" step="0.01" <?php if(isset($produto)): ?> value="<?php echo e($produto->preco); ?>" <?php endif; ?>>
              </div>

              <div class="form-group">
                  <label for="categoria">Categoria</label>
                  <select class="form-select form-select-sm" name="categoria" aria-label=".form-select-sm example">
                    <option selected>Selecione uma categoria</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
              <button class="btn btn-outline-info btn-sm" type="submit">Salvar</button>
              <button class="btn btn-outline-warning btn-sm" type="cancel">Cancelar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['current' => 'produtos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/novoproduto.blade.php ENDPATH**/ ?>