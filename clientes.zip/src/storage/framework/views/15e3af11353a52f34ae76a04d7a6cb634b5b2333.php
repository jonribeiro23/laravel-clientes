<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Cadastro de Produtos</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <?php $__env->startComponent('navbar_component', ['current' => $current]); ?>
        
    <?php echo $__env->renderComponent(); ?>
    <div class="container mt-5">
        <main role="main">
            <?php if (! empty(trim($__env->yieldContent('body')))): ?>
                <?php echo $__env->yieldContent('body'); ?>
            <?php endif; ?>
        </main>
    </div>

    <?php if (! empty(trim($__env->yieldContent('javascript')))): ?>
        <?php echo $__env->yieldContent('javascript'); ?>
    <?php endif; ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\jonat\Dropbox\PC\Documents\docs upLexis\cursos\laravel\clientes\src\resources\views/layouts/app.blade.php ENDPATH**/ ?>