<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cadastro de Produtos</title>
</head>
<body>
    <div class="container">
        <main role="main">
            <?php if (! empty(trim($__env->yieldContent('body')))): ?>
                <?php echo $__env->yieldContent('body'); ?>
            <?php endif; ?>
        </main>
    </div>
</body>
</html><?php /**PATH C:\Users\jonat\Dropbox\PC\Documents\docs upLexis\cursos\laravel\src\resources\views/layouts/app.blade.php ENDPATH**/ ?>