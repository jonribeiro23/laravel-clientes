;

<?php $__env->startSection('body'); ?>
    <div class="card border">
        <div class="card-body">
            <form <?php if(isset($categoria)): ?> action="/categorias/salvar/<?php echo e($categoria->id); ?>" <?php else: ?> action="/categorias" <?php endif; ?> method="post">
              <?php echo csrf_field(); ?>

              <?php if(isset($categoria)): ?>
                <?php echo method_field('PUT'); ?>
              <?php endif; ?>

              <div class="form-group">
                <label for="nomeCategoria">Nome</label>
                <input class="form-control" type="text" id="nomeCategoria" name="nome" <?php if(isset($categoria)): ?> value="<?php echo e($categoria->nome); ?>" <?php endif; ?>>
              </div>
              <button class="btn btn-outline-info btn-sm" type="submit">Salvar</button>
              <button class="btn btn-outline-warning btn-sm" type="cancel">Cancelar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['current' => 'categorias'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/novacategoria.blade.php ENDPATH**/ ?>